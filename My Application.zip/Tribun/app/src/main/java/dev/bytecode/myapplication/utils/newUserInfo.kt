package dev.bytecode.myapplication.utils

// Hold the user name of the newly signed up user
var newUserName: String = ""

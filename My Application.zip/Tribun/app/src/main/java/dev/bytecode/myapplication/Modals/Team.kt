package dev.bytecode.myapplication.Modals

data class Team(
    val id: String?,
    val name: String?,
    val imageUrl: String?,
    val infoUrl: String?
    )
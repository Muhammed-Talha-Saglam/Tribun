package dev.bytecode.myapplication.ui

import androidx.compose.ui.graphics.Color


val black = Color(0xFF000000)